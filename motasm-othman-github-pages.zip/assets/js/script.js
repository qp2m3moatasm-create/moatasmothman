/* =========================================================================
   Motasm Othman — Personal Site
   Vanilla JS, organized by feature. No build-time framework dependency.
   ========================================================================= */

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* -------------------------------------------------------------------------
   1. Loading screen
   ------------------------------------------------------------------------- */
function runLoader() {
  const loader = document.getElementById('loading-screen');
  const progress = document.querySelector('.loader-progress');
  if (!loader || !progress) {
    initAnimations();
    return;
  }

  let width = 0;
  let finished = false;
  let interval;

  const finish = () => {
    if (finished) return;
    finished = true;
    clearInterval(interval);
    progress.style.width = '100%';
    setTimeout(() => {
      loader.classList.add('loaded');
      loader.setAttribute('aria-hidden', 'true');
      initAnimations();
    }, prefersReducedMotion ? 0 : 350);
  };

  if (prefersReducedMotion) {
    finish();
    return;
  }

  interval = setInterval(() => {
    width += Math.random() * 30;
    if (width >= 100) {
      finish();
    } else {
      progress.style.width = width + '%';
    }
  }, 70);

  // Hard safety cap so the loader never blocks the site, regardless of
  // asset/network timing (fonts, images, slow connections, etc.).
  setTimeout(finish, 900);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', runLoader);
} else {
  runLoader();
}

/* -------------------------------------------------------------------------
   2. i18n (Arabic default / English)
   ------------------------------------------------------------------------- */
const translations = {
  ar: {
    skip_link: 'تخطَّ إلى المحتوى',
    nav_about: 'من أنا',
    nav_skills: 'المهارات',
    nav_gallery: 'معرض الأعمال',
    nav_contact: 'تواصل معي',
    greeting_morning: 'صباح الخير',
    greeting_evening: 'مساء الخير',
    roles: ['مصور فوتوغرافي', 'مصمم جرافيك', 'مونتير فيديو', 'مصور فوتوغرافي | مصمم | مونتير'],
    btn_contact: 'تواصل معي',
    btn_work: 'استكشف أعمالي',
    about_title: 'من أنا',
    about_p1: 'مرحبًا، أنا <span class="highlight">معتصم العثمان</span>، من <span class="highlight">سوريا</span> - محافظة <span class="highlight">إدلب</span>.',
    about_p2: 'أبلغ من العمر 18 عامًا، وأدرس في المرحلة الثانوية العامة.',
    about_p3: 'أعمل في مجال <span class="highlight">التصوير والتصميم والمونتاج</span>، وأسعى دائمًا إلى تطوير مهاراتي وصناعة أعمال إبداعية تجمع بين الجودة والابتكار.',
    about_p4: 'أهتم بالتقنيات الحديثة، وأطمح إلى بناء <span class="highlight">هوية رقمية احترافية</span> تعكس شغفي وإبداعي.',
    about_p5: 'مرحبًا بك في موقعي الشخصي، حيث يمكنك استكشاف أعمالي والتواصل معي عبر منصات التواصل الاجتماعي.',
    info_age_label: 'العمر',
    info_age_val: '18 عاماً',
    info_edu_label: 'الدراسة',
    info_edu_val: 'المرحلة الثانوية',
    info_prof_label: 'المهنة',
    info_prof_val: 'تصوير، تصميم، مونتاج',
    info_loc_label: 'الموقع',
    info_loc_val: 'إدلب، سوريا',
    social_title: 'المنصات',
    skills_title: 'المهارات',
    skill_photo: 'التصوير الفوتوغرافي',
    skill_design: 'التصميم الجرافيكي',
    skill_video: 'المونتاج وتعديل الفيديو',
    skill_content: 'صناعة المحتوى',
    stat_exp: 'سنوات خبرة',
    stat_proj: 'مشروع مكتمل',
    stat_clients: 'عميل سعيد',
    stat_platforms: 'منصات نشطة',
    gallery_title: 'معرض الأعمال',
    gallery_soon: 'قريباً',
    contact_title: 'تواصل معي',
    contact_scan: 'امسح الكود لزيارة الموقع',
    contact_wa: 'تواصل عبر واتساب',
    contact_copy_user: 'نسخ المعرف (<bdi dir="ltr">@qp2m9</bdi>)',
    contact_share: 'مشاركة الموقع',
    contact_copy_site: 'نسخ رابط الموقع',
    footer_copy: '© 2026 معتصم العثمان. جميع الحقوق محفوظة.',
    toast_copied: 'تم النسخ بنجاح!',
    toast_copy_failed: 'تعذّر النسخ، حاول مرة أخرى.',
    not_found_text: 'الصفحة التي تبحث عنها غير موجودة. عد إلى الصفحة الرئيسية لاستكشاف الموقع.',
    not_found_btn: 'العودة إلى الرئيسية'
  },
  en: {
    skip_link: 'Skip to content',
    nav_about: 'About',
    nav_skills: 'Skills',
    nav_gallery: 'Gallery',
    nav_contact: 'Contact',
    greeting_morning: 'Good Morning',
    greeting_evening: 'Good Evening',
    roles: ['Photographer', 'Graphic Designer', 'Video Editor', 'Photographer | Designer | Editor'],
    btn_contact: 'Contact Me',
    btn_work: 'View My Work',
    about_title: 'About Me',
    about_p1: 'Hello, I am <span class="highlight">Motasm Othman</span>, from <span class="highlight">Syria</span> - <span class="highlight">Idlib</span> province.',
    about_p2: 'I am 18 years old, currently studying in high school.',
    about_p3: 'I work in <span class="highlight">Photography, Design, and Video Editing</span>. I constantly strive to develop my skills and create creative works combining quality and innovation.',
    about_p4: 'I am interested in modern technologies and aspire to build a <span class="highlight">professional digital identity</span> reflecting my passion and creativity.',
    about_p5: 'Welcome to my personal website, where you can explore my work and connect with me across social platforms.',
    info_age_label: 'Age',
    info_age_val: '18 Years',
    info_edu_label: 'Education',
    info_edu_val: 'High School',
    info_prof_label: 'Profession',
    info_prof_val: 'Photography, Design, Video Editing',
    info_loc_label: 'Location',
    info_loc_val: 'Idlib, Syria',
    social_title: 'Platforms',
    skills_title: 'Skills',
    skill_photo: 'Photography',
    skill_design: 'Graphic Design',
    skill_video: 'Video Editing',
    skill_content: 'Content Creation',
    stat_exp: 'Years Experience',
    stat_proj: 'Completed Projects',
    stat_clients: 'Happy Clients',
    stat_platforms: 'Active Platforms',
    gallery_title: 'Portfolio Gallery',
    gallery_soon: 'Coming Soon',
    contact_title: 'Get In Touch',
    contact_scan: 'Scan to visit site',
    contact_wa: 'Contact via WhatsApp',
    contact_copy_user: 'Copy Username (<bdi dir="ltr">@qp2m9</bdi>)',
    contact_share: 'Share Website',
    contact_copy_site: 'Copy Website Link',
    footer_copy: '© 2026 Motasm Othman. All rights reserved.',
    toast_copied: 'Copied successfully!',
    toast_copy_failed: 'Could not copy, please try again.',
    not_found_text: "The page you're looking for doesn't exist. Head back home to explore the site.",
    not_found_btn: 'Back to home'
  }
};

let currentLang = localStorage.getItem('lang') || 'ar';
const htmlElement = document.documentElement;

function setLanguage(lang) {
  currentLang = lang;
  localStorage.setItem('lang', lang);
  htmlElement.setAttribute('lang', lang);
  htmlElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');

  const toggleBtn = document.getElementById('lang-toggle');
  if (toggleBtn) toggleBtn.textContent = lang === 'ar' ? 'EN' : 'AR';

  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang][key]) {
      el.innerHTML = translations[lang][key];
    }
  });

  roles = translations[lang].roles;
  roleIndex = 0;
  charIndex = 0;
  const typewriterEl = document.getElementById('typewriter');
  if (typewriterEl) typewriterEl.textContent = '';

  updateGreeting();
  renderNotFound();
}

document.getElementById('lang-toggle')?.addEventListener('click', () => {
  setLanguage(currentLang === 'ar' ? 'en' : 'ar');
});

/* -------------------------------------------------------------------------
   3. Theme (dark / light)
   ------------------------------------------------------------------------- */
let currentTheme = localStorage.getItem('theme') || 'dark';
function setTheme(theme) {
  currentTheme = theme;
  localStorage.setItem('theme', theme);
  document.body.classList.toggle('light', theme === 'light');
  document.body.classList.toggle('dark', theme !== 'light');
  const themeBtn = document.getElementById('theme-toggle');
  if (themeBtn) themeBtn.setAttribute('aria-pressed', String(theme === 'light'));
}

document.getElementById('theme-toggle')?.addEventListener('click', () => {
  setTheme(currentTheme === 'dark' ? 'light' : 'dark');
});

/* -------------------------------------------------------------------------
   4. Live clock & greeting
   ------------------------------------------------------------------------- */
function updateTime() {
  const el = document.getElementById('live-time');
  if (!el) return;
  const now = new Date();
  const options = { hour: '2-digit', minute: '2-digit', hour12: true };
  el.textContent = now.toLocaleTimeString(currentLang === 'ar' ? 'ar-SY' : 'en-US', options);
}
function updateGreeting() {
  const hour = new Date().getHours();
  const greetingEl = document.getElementById('live-greeting');
  if (!greetingEl) return;
  greetingEl.textContent = hour < 12
    ? translations[currentLang].greeting_morning
    : translations[currentLang].greeting_evening;
}
setInterval(updateTime, 1000);

/* -------------------------------------------------------------------------
   5. Typewriter effect
   ------------------------------------------------------------------------- */
let roles = translations[currentLang].roles;
let roleIndex = 0;
let charIndex = 0;
let isDeleting = false;
let typeDelay = 100;
let typewriterTimer = null;

function typeWriter() {
  const el = document.getElementById('typewriter');
  if (!el) return;
  const currentRole = roles[roleIndex];

  if (isDeleting) {
    el.textContent = currentRole.substring(0, charIndex - 1);
    charIndex--;
    typeDelay = 50;
  } else {
    el.textContent = currentRole.substring(0, charIndex + 1);
    charIndex++;
    typeDelay = 100;
  }

  if (!isDeleting && charIndex === currentRole.length) {
    isDeleting = true;
    typeDelay = prefersReducedMotion ? 1000 : 2000;
  } else if (isDeleting && charIndex === 0) {
    isDeleting = false;
    roleIndex = (roleIndex + 1) % roles.length;
    typeDelay = 500;
  }

  clearTimeout(typewriterTimer);
  typewriterTimer = setTimeout(typeWriter, typeDelay);
}

/* -------------------------------------------------------------------------
   6. Scroll reveal animations + counters
   ------------------------------------------------------------------------- */
function initAnimations() {
  if (prefersReducedMotion) {
    document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right, .reveal-scale').forEach(el => {
      el.classList.add('active');
    });
    document.querySelectorAll('.skill-bar-fill').forEach(fill => {
      fill.style.width = fill.getAttribute('data-width');
    });
    document.querySelectorAll('.counter').forEach(counter => {
      counter.textContent = counter.getAttribute('data-target');
    });
    return;
  }

  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');

        if (entry.target.classList.contains('skill-item')) {
          const fill = entry.target.querySelector('.skill-bar-fill');
          if (fill) fill.style.width = fill.getAttribute('data-width');
        }

        if (entry.target.classList.contains('stat-card')) {
          const counter = entry.target.querySelector('.counter');
          if (counter && !counter.classList.contains('counted')) {
            animateCounter(counter);
            counter.classList.add('counted');
          }
        }

        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  document.querySelectorAll('.reveal-up, .reveal-left, .reveal-right, .reveal-scale').forEach(el => {
    observer.observe(el);
  });
}

function animateCounter(el) {
  const target = parseInt(el.getAttribute('data-target'), 10);
  const duration = 2000;
  const step = target / (duration / 16);
  let current = 0;

  const timer = setInterval(() => {
    current += step;
    if (current >= target) {
      el.textContent = target;
      clearInterval(timer);
    } else {
      el.textContent = Math.floor(current);
    }
  }, 16);
}

/* -------------------------------------------------------------------------
   7. Navbar: scrolled state, scroll-spy, back-to-top
   ------------------------------------------------------------------------- */
const navbar = document.getElementById('navbar');
const bttBtn = document.getElementById('back-to-top');
const navLinks = document.querySelectorAll('.nav-link[data-section]');
const sections = Array.from(navLinks)
  .map(link => document.getElementById(link.getAttribute('data-section')))
  .filter(Boolean);

let scrollTicking = false;
function onScroll() {
  if (navbar) navbar.classList.toggle('scrolled', window.scrollY > 50);
  if (bttBtn) bttBtn.classList.toggle('visible', window.scrollY > 500);

  let activeId = null;
  const atBottom = window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 2;
  if (atBottom && sections.length) {
    activeId = sections[sections.length - 1].id;
  } else {
    const scrollPos = window.scrollY + window.innerHeight * 0.3;
    sections.forEach(section => {
      if (section.offsetTop <= scrollPos) {
        activeId = section.id;
      }
    });
  }
  navLinks.forEach(link => {
    link.classList.toggle('active', link.getAttribute('data-section') === activeId);
  });

  scrollTicking = false;
}

window.addEventListener('scroll', () => {
  if (!scrollTicking) {
    requestAnimationFrame(onScroll);
    scrollTicking = true;
  }
}, { passive: true });

bttBtn?.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
});

/* -------------------------------------------------------------------------
   8. Mobile menu
   ------------------------------------------------------------------------- */
const mobileBtn = document.getElementById('mobile-menu-btn');
const mobileMenu = document.getElementById('mobile-menu');
const mobileLinks = document.querySelectorAll('.mobile-nav-link');

function closeMobileMenu() {
  mobileMenu?.classList.remove('active');
  mobileMenu?.setAttribute('aria-hidden', 'true');
  mobileBtn?.setAttribute('aria-expanded', 'false');
}

function openMobileMenu() {
  mobileMenu?.classList.add('active');
  mobileMenu?.setAttribute('aria-hidden', 'false');
  mobileBtn?.setAttribute('aria-expanded', 'true');
}

mobileBtn?.addEventListener('click', () => {
  const isOpen = mobileMenu?.classList.contains('active');
  if (isOpen) closeMobileMenu(); else openMobileMenu();
});

mobileLinks.forEach(link => {
  link.addEventListener('click', closeMobileMenu);
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && mobileMenu?.classList.contains('active')) {
    closeMobileMenu();
    mobileBtn?.focus();
  }
});

/* -------------------------------------------------------------------------
   9. Mouse glow (rAF-throttled for smooth performance)
   ------------------------------------------------------------------------- */
const mouseGlow = document.getElementById('mouse-glow');
if (mouseGlow && !prefersReducedMotion && !window.matchMedia('(pointer: coarse)').matches) {
  let mouseX = 0, mouseY = 0, glowTicking = false;
  document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    if (!glowTicking) {
      requestAnimationFrame(() => {
        mouseGlow.style.left = mouseX + 'px';
        mouseGlow.style.top = mouseY + 'px';
        glowTicking = false;
      });
      glowTicking = true;
    }
  }, { passive: true });
} else if (mouseGlow) {
  mouseGlow.style.display = 'none';
}

/* -------------------------------------------------------------------------
   10. Toast + clipboard / share actions
   ------------------------------------------------------------------------- */
let toastTimer = null;
function showToast(msg) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

async function copyText(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
    } else {
      // Fallback for older browsers / non-secure contexts.
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
    }
    showToast(translations[currentLang].toast_copied);
  } catch (err) {
    showToast(translations[currentLang].toast_copy_failed);
  }
}

document.getElementById('copy-user')?.addEventListener('click', () => {
  copyText('@qp2m9');
});

document.getElementById('copy-site')?.addEventListener('click', () => {
  copyText(window.location.href);
});

document.getElementById('share-site')?.addEventListener('click', async () => {
  if (navigator.share) {
    try {
      await navigator.share({ title: 'Motasm Othman', url: window.location.href });
    } catch (err) {
      if (err && err.name !== 'AbortError') {
        copyText(window.location.href);
      }
    }
  } else {
    copyText(window.location.href);
  }
});

/* -------------------------------------------------------------------------
   11. QR code (loaded lazily from CDN, with graceful fallback)
   ------------------------------------------------------------------------- */
function loadQR() {
  const canvas = document.getElementById('qr-code');
  if (!canvas) return;

  const script = document.createElement('script');
  script.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js';
  script.async = true;
  script.onload = () => {
    if (typeof QRious === 'undefined') return;
    new QRious({
      element: canvas,
      value: window.location.href,
      size: 150,
      background: 'white',
      foreground: 'black'
    });
  };
  script.onerror = () => {
    const label = canvas.closest('.qr-container')?.querySelector('.qr-label');
    if (label) label.textContent = window.location.href;
  };
  document.body.appendChild(script);
}

/* -------------------------------------------------------------------------
   12. Particle background (skipped/simplified under reduced-motion)
   ------------------------------------------------------------------------- */
function initParticles() {
  const canvas = document.getElementById('particles-bg');
  if (!canvas || prefersReducedMotion) {
    if (canvas) canvas.style.display = 'none';
    return;
  }
  const ctx = canvas.getContext('2d');

  let width, height, particles, rafId, resizeTimer;

  function resize() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }

  class Particle {
    constructor() {
      this.x = Math.random() * width;
      this.y = Math.random() * height;
      this.vx = (Math.random() - 0.5) * 0.5;
      this.vy = (Math.random() - 0.5) * 0.5;
      this.size = Math.random() * 2;
    }
    update() {
      this.x += this.vx;
      this.y += this.vy;

      if (this.x < 0 || this.x > width) this.vx *= -1;
      if (this.y < 0 || this.y > height) this.vy *= -1;
    }
    draw() {
      ctx.fillStyle = currentTheme === 'dark' ? 'rgba(255,255,255,0.3)' : 'rgba(0,0,0,0.2)';
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function init() {
    resize();
    particles = [];
    const count = window.innerWidth < 768 ? 30 : 70;
    for (let i = 0; i < count; i++) {
      particles.push(new Particle());
    }
  }

  function animate() {
    ctx.clearRect(0, 0, width, height);

    for (let i = 0; i < particles.length; i++) {
      particles[i].update();
      particles[i].draw();

      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 100) {
          ctx.beginPath();
          const opacity = currentTheme === 'dark' ? (1 - dist / 100) * 0.15 : (1 - dist / 100) * 0.05;
          ctx.strokeStyle = currentTheme === 'dark' ? `rgba(255,255,255,${opacity})` : `rgba(0,0,0,${opacity})`;
          ctx.lineWidth = 0.5;
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }

    rafId = requestAnimationFrame(animate);
  }

  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      cancelAnimationFrame(rafId);
      init();
      animate();
    }, 200);
  }, { passive: true });

  init();
  animate();
}

/* -------------------------------------------------------------------------
   13. Client-side "not found" view for unknown deep links.
   This is a single-page site with in-page anchors only (`#about`, etc.).
   Some hosts rewrite every path to index.html (see artifact.toml), so any
   unexpected pathname is handled here rather than by a separate
   server-rendered 404 page. The "home" check is path-prefix agnostic so it
   works whether the site is served from a domain root ("/") or a subpath
   (e.g. a GitHub Pages project site at "/repo-name/").
   ------------------------------------------------------------------------- */
function renderNotFound() {
  const path = window.location.pathname;
  const isHome = path === '' || path.endsWith('/') || path.endsWith('/index.html');
  if (isHome) return;

  const main = document.getElementById('main-content');
  if (!main) return;

  const t = translations[currentLang];
  main.innerHTML = `
    <div class="not-found-view">
      <div class="not-found-code gradient-text">404</div>
      <p class="not-found-text">${t.not_found_text}</p>
      <a href="./" class="btn btn-primary">${t.not_found_btn}</a>
    </div>
  `;
}

/* -------------------------------------------------------------------------
   14. Runtime canonical / OG url
   The real production domain isn't known at build time, so canonical and
   og:url are set from the actual location instead of being hardcoded.
   ------------------------------------------------------------------------- */
function setCanonicalUrl() {
  const url = window.location.origin + window.location.pathname;
  const canonical = document.getElementById('canonical-link');
  if (canonical) canonical.setAttribute('href', url);
  const ogUrl = document.getElementById('og-url');
  if (ogUrl) ogUrl.setAttribute('content', url);
}

/* -------------------------------------------------------------------------
   Init
   ------------------------------------------------------------------------- */
setCanonicalUrl();
setLanguage(currentLang);
setTheme(currentTheme);
updateTime();
updateGreeting();
typeWriter();
initParticles();
loadQR();

// Run once after layout settles (and again on 'load') so a direct deep-link
// to an anchor (e.g. reloading on #contact) highlights the right nav item
// instead of relying only on the next scroll event.
requestAnimationFrame(() => requestAnimationFrame(onScroll));
window.addEventListener('load', onScroll);
